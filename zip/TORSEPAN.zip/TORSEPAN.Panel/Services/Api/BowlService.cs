﻿using TORSEPAN.Panel.Models;

namespace TORSEPAN.Panel.Services.Api;

public sealed class BowlService
{
    private readonly ApiClient _api;

    public BowlService(ApiClient api)
    {
        _api = api;
    }

    public async Task<IReadOnlyList<BowlDto>> GetAsync()
    {
        var result =
            await _api.GetAsync<PagedResult<BowlDto>>("api/bowls");

        return result?.Items ?? [];
    }

    public async Task<Guid?> CreateAsync(CreateBowlRequest request)
    {
        return await _api.PostAsync<CreateBowlRequest, Guid?>(
            "api/bowls",
            request);
    }
}