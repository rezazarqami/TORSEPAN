﻿using TORSEPAN.Domain.Common;
using TORSEPAN.Domain.Enums;
using TORSEPAN.Domain.Production;

namespace TORSEPAN.Domain.Entities;

public class Handpan : Entity
{
    private readonly List<ProductionEvent> _productionEvents = new();

    private Handpan()
    {
    }

    public Handpan(Guid assemblyId, string serialNumber)
    {
        Id = Guid.NewGuid();
        AssemblyId = assemblyId;
        SerialNumber = serialNumber;
        CreatedAt = DateTime.UtcNow;
    }

    public Guid AssemblyId { get; private set; }

    public HandpanAssembly Assembly { get; private set; } = null!;

    public string SerialNumber { get; private set; } = string.Empty;

    public ProductionStatus Status { get; private set; }

    public ProductionStage Stage { get; private set; }

    public DateTime CreatedAt { get; private set; }

    public DateTime? UpdatedAt { get; private set; }

    public IReadOnlyCollection<ProductionEvent> ProductionEvents => _productionEvents;

    public void RegisterProductionOperation(
        ProductionTransition transition,
        Guid userId,
        EventResult result,
        OperationDuration? duration,
        string description)
    {
        if (!Enum.TryParse<ProductionAction>(
            transition.ToString(),
            true,
            out var action))
        {
            action = default;
        }

        _productionEvents.Add(
            new ProductionEvent(
                handpanId: Id,
                assemblyId: AssemblyId,
                bowlId: null,
                userId: userId,
                action: action,
                result: result,
                duration: duration,
                description: description));

        UpdatedAt = DateTime.UtcNow;
    }

    public void CompleteProduction()
    {
        UpdatedAt = DateTime.UtcNow;
    }

    public void Reject()
    {
        UpdatedAt = DateTime.UtcNow;
    }

    public void ChangeStage(ProductionStage stage)
    {
        Stage = stage;
        UpdatedAt = DateTime.UtcNow;
    }

    public void ChangeStatus(ProductionStatus status)
    {
        Status = status;
        UpdatedAt = DateTime.UtcNow;
    }
}